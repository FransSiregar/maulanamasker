<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Employee extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->library('form_validation');
  }

  public function index()
  {
    $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'required|trim');

    if ($this->form_validation->run() == false) {
      $data['title'] = "Login Employee";
      $this->load->view('templates/auth_header', $data);
      $this->load->view('auth/loginEmployee');
      $this->load->view('templates/auth_footer', $data);
    } else {
      $this->_loginEmployee();
    }
  }

  private function _loginEmployee()
  {
    $email = $this->input->post('email');
    $password  = $this->input->post('password');

    $admin = $this->db->get_where('admin', ['email' => $email])->row();

    if ($admin) {
      if (password_verify($password, $admin->password)) {
        $data = [
          'admin_id' => $admin->admin_id,
          'email' => $admin->email,
          'username' => $admin->username,
        ];
        $this->session->set_userdata($data);
        redirect('admin/overview');
      } else {
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Salah!!</div>');
        redirect('auth/Employee');
      }
    } else {
      $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Login Gagal!!</div>');
      redirect('auth/Employee');
    }
  }

  public function registration()
  {
    $this->form_validation->set_rules('Username', 'username', 'required|trim');
    $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[employee.email]', ['is_unique' => 'Email Sudah Terdaftar!']);
    $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[3]|matches[password2]', [
      'matches' => 'Password Tidak Sama!',
      'min_length' => 'Password Terlalu Pendek!'
    ]);
    $this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');

    if ($this->form_validation->run() == false) {
      $data['title'] = 'Registrasi Employee';
      $data['admin'] = $this->Level_model->level_getAll();
      $this->load->view('templates/auth_header', $data);
      $this->load->view('auth/registrationEmployee');
      $this->load->view('templates/auth_footer', $data);
    } else {
      $data = [
        'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
        'name' => htmlspecialchars($this->input->post('name', true)),
        'email' => htmlspecialchars($this->input->post('email', true)),
      ];

      $this->db->insert('employee', $data);
      $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Registrasi Telah Berhasil!!. Silahkan Login!</div>');
      redirect('auth/Employee');
    }
  }

  public function logout()
  {
    $this->session->sess_destroy();
    $this->session->mark_as_flash('message', '<div class="alert alert-success" role="alert">Registrasi Telah Berhasil!!. Silahkan Login!</div>');
    redirect('auth/Employee');
  }
}