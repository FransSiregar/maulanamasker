<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view("admin/_partials/head.php"); ?>
</head>
<body class="sb-nav-fixed">
    <?php $this->load->view("admin/_partials/navbar.php"); ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php $this->load->view("admin/_partials/sidebar.php"); ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Dashboard</h1>
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                    <div class="container mt-5">
                        <div class="text-center mb-3">
                            <h3>Contact us</h3>
                        </div>
                        <div class="row g-2">
                            <div class="col-md-4">
                                <div class="card"> <img src="https://i.imgur.com/xuGJbnU.png" width="40">
                                    <h5>Address</h5>
                                    <p>Jl. Babarsari No.43, Janti, Caturtunggal, Kec. Depok, Kabupaten Sleman, Daerah Istimewa Yogyakarta</p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card"> <img src="https://i.imgur.com/TNKflal.png" width="40">
                                    <h5>Email</h5>
                                    <p>Tokobuku@gmail.com</p>
                                    <P><p><p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card"> <img src="https://i.imgur.com/pZLFSO3.png" width="40">
                                        <h5>Phone</h5>
                                        <p>( 021 ) 28902929</p>
                                        <P><p><p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </main>
                        <?php $this->load->view("admin/_partials/footer.php"); ?>
                    </div>
                </div>
                <?php $this->load->view("admin/_partials/modal.php"); ?>
                <?php $this->load->view("admin/_partials/js.php"); ?>
            </body>
            </html>


