<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view("admin/_partials/head.php"); ?>
</head>
<body class="sb-nav-fixed">
    <?php $this->load->view("admin/_partials/navbar.php"); ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php $this->load->view("admin/_partials/sidebar.php"); ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Dashboard</h1>
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                    <div class="row">
                       <h1>Pengalaman Organisasi</h1>
                       <p>Saya pernah bergabung dengan Keluarga Besar Mahasiswa Daya Atma Jaya/KBMDA yaitu menjadi bagian dari divisi seni budaya yang dimana saya bersama teman-teman yang lain saling berdinamika dalam semangat untuk melestarikan kebudayaan dayak dengan memainkan musik tradisional yang mungkin kurang diminati pada zaman sekarang.</p>
                   </main>
                   <?php $this->load->view("admin/_partials/footer.php"); ?>
               </div>
           </div>
           <?php $this->load->view("admin/_partials/modal.php"); ?>
           <?php $this->load->view("admin/_partials/js.php"); ?>
       </body>
       </html>