<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav <?php echo $this->uri->segment(2) == ''? 'active': ''?>">
            <div class="sb-sidenav-menu-heading text-success">Core</div>
            <a class="nav-link" href="<?= base_url("admin/Overview") ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
            </a>
            <a class="nav-link" href="<?php echo base_url('Welcome/about')?>">
                <div class="sb-nav-link-icon"><i class="fas fa-user-friends"></i></div>
                About   
            </a>
            <a class="nav-link" href="<?php echo base_url('Welcome/contact')?>">
                <div class="sb-nav-link-icon"><i class="fas fa-address-card"></i></div>
                Contact
            </a>

            <div class="sb-sidenav-menu-heading text-success">Transaksi</div>
            <a class="nav-link" href="<?= base_url("admin/Penjualan") ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-balance-scale"></i></div>
                Penjualan
            </a>

            <a class="nav-link" href="<?php echo site_url('admin/Penjualan/list_penjualan')?>">
             <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
             Laporan Penjualan
         </a>

         <a class="nav-link" href="<?php echo site_url('admin/Penjualan/chart')?>">
            <div class="sb-nav-link-icon"><i class="fas fa-balance-scale"></i></div>
            Chart Penjualan
        </a>

        <a class="nav-link" href="<?= base_url("admin/Pembelian") ?>">
            <div class="sb-nav-link-icon"><i class="fas fa-piggy-bank"></i></div>
            Pembelian
        </a>

        <a class="nav-link" href="<?php echo site_url('admin/Pembelian/list_pembelian')?>">
         <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
         Laporan Pembelian
     </a>

     <a class="nav-link" href="<?php echo site_url('admin/Pembelian/chart')?>">
        <div class="sb-nav-link-icon"><i class="fas fa-balance-scale"></i></div>
        Chart Pembelian
    </a>


    <div class="sb-sidenav-menu-heading text-success">Tugas</div>
    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
        <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
        Kumpulan Tugas
        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
    </a>

    <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
        <nav class="sb-sidenav-menu-nested nav">
            <a class="nav-link" href="<?php echo base_url('Welcome/biodatadiri')?>">
                <div class="sb-nav-link-"><i class=""></i></i></div>
                Data Diri
                <a class="nav-link" href="<?php echo base_url('Welcome/pengalamanorganisasi')?>">
                    <div class="sb-nav-link-"><i class=""></i></i></div>
                    Pengalaman Organisasi

                    <a class="nav-link" href="<?php echo base_url('Welcome/container')?>">
                        <div class="sb-nav-link-"><i class=""></i></i></div>
                        Tugas Kontainer

                        <a class="nav-link" href="<?php echo base_url('Welcome/deskripsidiri')?>">
                            <div class="sb-nav-link-"><i class=""></i></i></div>
                            Deskripsi Diri

                        </a> 
                    </nav>
                </div>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseDataMaster" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Data Master
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseDataMaster" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo site_url('admin/author') ?>">Author</a>
                        <a class="nav-link" href="<?php echo site_url('admin/Bookcategory ') ?>">Book Category</a>
                        <a class="nav-link" href="<?php echo site_url('admin/supplier') ?>">Supplier</a>
                        <a class="nav-link" href="<?php echo site_url('admin/Customer') ?>"> Customer</a>
                        <a class="nav-link" href="<?php echo site_url('admin/Level') ?>">Level</a>
                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#groceryCRUD" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Grocery Example
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="groceryCRUD" aria-labelledby="heading" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo site_url('examples/customers_management') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Customers
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples/orders_management')?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Orders
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples/products_management')?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Products
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples/offices_management')?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Office
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples/employees_management')?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Employees
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples/film_management')?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Film
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples/multigrids')?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Multigrid [BETA]
                        </a>
                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#groceryTokobuku" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Grocery CRUD
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="groceryTokobuku" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo site_url('examples2/Author') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Author
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples2/Bookcategory') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Book Category
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples2/Supplier') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Supplier
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples2/Customer') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Customer
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples2/Level') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Level
                        </a>
                        <a class="nav-link" href="<?php echo site_url('examples2/Book') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Book
                        </a>
                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Pages
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                            Authentication
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="login.html">Login</a>
                                <a class="nav-link" href="register.html">Register</a>
                                <a class="nav-link" href="password.html">Forgot Password</a>
                            </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                            Error
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="401.html">401 Page</a>
                                <a class="nav-link" href="404.html">404 Page</a>
                                <a class="nav-link" href="500.html">500 Page</a>
                            </nav>
                        </div>
                    </nav>
                </div>
                <div class="sb-sidenav-menu-heading text-success">Addons</div>
                <a class="nav-link" href="charts.html">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Charts
                </a>
                <a class="nav-link" href="tables.html">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Tables
                </a>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Fransiskus Febrianto Parulian Siregar
        </div>

    </nav>