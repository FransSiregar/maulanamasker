<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view("admin/_partials/head.php"); ?>
</head>
<body class="sb-nav-fixed">
    <?php $this->load->view("admin/_partials/navbar.php"); ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php $this->load->view("admin/_partials/sidebar.php"); ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Dashboard</h1>
                    <?php $this->load->view("admin/_partials/breadcrumb.php"); ?>
                    <div class="row">
                        <div class="col-md-12 bg-warning">
                            <h3>
                                <center>Container 1 - Gambar</center>
                            </h3>
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-md-4 pb-2 bg-primary text-dark">
                            <img class='img-fluid w-100'>
                            <img src="/tokobuku/assets/img/uajy.png" class="img-thumbnail mx-auto d-block" width="auto" height="auto">
                            <center><b>Logo UAJY</b></center>
                        </div>

                        <div class="col-md-4 pb-2 bg-dark text-light">
                            <img class='img-fluid w-100'>
                            <img class='img-fluid w-100'>
                            <img class='img-fluid w-100'>
                            <img class='img-fluid w-100'>
                            <img src="/tokobuku/assets/img/profil.jpg" class="img-thumbnail mx-auto d-block" width="auto" height="auto">
                            <center><b></b>Foto Diri</center>
                        </div>

                        <div class="col-md-4 pb-2 bg-success text-dark"> 
                            <img class='img-fluid w-100'>
                            <img class='img-fluid w-100'>
                            <img class='img-fluid w-100'>  
                            <img class='img-fluid w-100'>    
                            <img src="/tokobuku/assets/img/Bonaventura.jpg" class="img-thumbnail mx-auto d-block" width="auto" height="auto">
                            <center><b>Gedung Bonaventura</b></center>
                        </div>
                    </div>
                </div>
                <br>
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-md-10 bg-success">
                            <h3>
                                <center>Container 2 - Pesan dan Kesan</center>
                            </h3>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-5 bg-info text-dark">
                            <h3>
                                <center>Pengalaman Belajar SIWEB</center>
                            </h3>
                            <p>
                                <center>Ketika belajar siweb saya banyak mendapatkan pelajaran bagaimana caranya membuat sebuah website walaupun dalam pembelajaran pada awalnya saya merasa kesulitan adaptasi terhadap software yang digunakan.</center>
                            </p>
                        </div>
                        <div class="col-md-5 bg-warning text-dark">
                            <h3>
                                <center>Kepada Dosen dan Asdos</center>
                            </h3>
                            <p><center>Pesan untuk dosen dan asdos jangan pernah berhenti memberikan materi yang bermanfaat bagi para peserta didik. Kesan dari saya selama mengikuti kelas SIWEB saya merasa sangat senang karena dosen dan asdos tidak segan untuk berbagi ilmu yang mereka punya kepada peserta didik.<center></p>
                            </div>
                        </div>
                    </div>
                </main>
                <?php $this->load->view("admin/_partials/footer.php"); ?>
            </div>
        </div>
        <?php $this->load->view("admin/_partials/modal.php"); ?>
        <?php $this->load->view("admin/_partials/js.php"); ?>
    </body>
    </html>
